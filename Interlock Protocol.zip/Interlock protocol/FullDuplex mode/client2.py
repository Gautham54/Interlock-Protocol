import socket
import time
import Crypto
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

server=socket.socket()
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind(("127.0.0.1",9999))

server.listen(10)
key = RSA.generate(3072)
private_key,public = key, key.publickey()   

def INTERLOCK(con,addr):
    while True:
       con.send(key.publickey().exportKey(format='PEM', passphrase=None, pkcs=1))
       pub = RSA.importKey(con.recv(2048), passphrase=None)
       cipher=con.recv(2048)
       rsa_private_key = PKCS1_OAEP.new(private_key)
       decrypted_text1 = rsa_private_key.decrypt(cipher)
       if(decrypted_text1.decode()=='bye'):
           print('connection is going to close')
           exit()
       print("First half of the message is recieved")
       print(decrypted_text1)
       print("write your meassage")
       k=input()
       if(k=='bye'):
           rsa_public_key = PKCS1_OAEP.new(pub)
           encrypted_text = rsa_public_key.encrypt(k.encode())
           con.send(encrypted_text)
           exit()
       f=k[:len(k)//2].encode()
       s=k[len(k)//2:].encode()
       rsa_public_key = PKCS1_OAEP.new(pub)
       encrypted_text = rsa_public_key.encrypt(f)
       con.send(encrypted_text)
       cipher=con.recv(2048)   
       if(len(cipher)):  
         enc=rsa_public_key.encrypt(s)
         con.send(enc)
         decrypted_text2 = rsa_private_key.decrypt(cipher)
         decrypted_text1=decrypted_text1.decode()
         decrypted_text2=decrypted_text2.decode()
        # print("second half message recieved:{}".format(decrypted_text2))
         print("Final message:{}".format(decrypted_text1+decrypted_text2))

while True:
    con,addr=server.accept()
    print('ready to start chat')
    INTERLOCK(con,addr)

con.close()
server.close()
